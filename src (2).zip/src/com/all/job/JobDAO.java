package com.all.job;

public class JobDAO {
	

}
