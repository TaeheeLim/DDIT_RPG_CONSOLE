package com.all.monsters;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		MonstersDAO dao = new MonstersDAO();
	}

}
